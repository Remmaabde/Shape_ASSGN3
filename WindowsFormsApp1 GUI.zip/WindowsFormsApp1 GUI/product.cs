﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Console;

namespace WindowsFormsApp1_GUI
{
    internal class product
    {
        public String productName { get; set; }
          

        public String productprice { get; set; }  

        public String Quantity { get; set; }  
        
        public void save()
        {
            MessageBox.Show("Saved");
        }

    }
}
